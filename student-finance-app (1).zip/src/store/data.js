const KEY = 'sf_data_v3';
const blank = { user: null, balance: 0, emergency: 0, transactions: [] };

export function load(){ try{ return JSON.parse(localStorage.getItem(KEY)) || blank }catch{ return blank } }
export function save(d){ localStorage.setItem(KEY, JSON.stringify(d)); }

export function setUser(u){ const d=load(); d.user=u; save(d); }
export function addTx(tx){
  const d=load();
  const id=Date.now();
  const t={ id, ...tx };
  d.transactions.unshift(t);
  if(tx.type==='expense') d.balance-=tx.amount;
  if(tx.type==='income') d.balance+=tx.amount;
  save(d);
  return id;
}
export function setEmergency(v){ const d=load(); d.emergency=v; save(d); }
