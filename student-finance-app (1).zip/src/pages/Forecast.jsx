import Mascot from '../components/Mascot.jsx';
import { load } from '../store/data.js';

export default function Forecast(){
  const d = load();
  const expenses = d.transactions.filter(t=>t.type==='expense');
  const dailyAvg = expenses.length ? Math.round(expenses.reduce((a,t)=>a+t.amount,0)/Math.max(1, new Set(d.transactions.map(t=>t.date)).size)) : 0;
  const daysLeft = dailyAvg>0 ? Math.max(0, Math.floor(d.balance / dailyAvg)) : '∞';

  return (
    <div className="h-full p-5">
      <div className="flex items-center gap-3 mb-3">
        <Mascot sheet="3x3" index={8} size={40}/>
        <h1 className="text-xl font-bold">Forecast</h1>
      </div>
      <div className="bg-yellow-100 border border-yellow-200 rounded-2xl p-4">
        <div className="font-semibold mb-1">At this pace:</div>
        <div className="text-lg">Balance lasts <span className="font-bold">{String(daysLeft)}</span> days.</div>
        <p className="text-sm text-neutral-600 mt-2">Tip: reduce the top category by ₹100/day to extend runway.</p>
      </div>
    </div>
  );
}
