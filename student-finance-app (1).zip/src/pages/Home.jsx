import Header from '../components/Header.jsx';
import BalanceCard from '../components/BalanceCard.jsx';
import Nudges from '../components/Nudges.jsx';
import TransactionList from '../components/TransactionList.jsx';

export default function Home(){
  return (
    <div className="h-full flex flex-col bg-white">
      <Header poseIndex={1}/>
      <BalanceCard/>
      <Nudges/>
      <TransactionList/>
    </div>
  );
}
