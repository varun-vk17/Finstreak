import Mascot from '../components/Mascot.jsx';
import { load } from '../store/data.js';
import { useMemo, useState } from 'react';

export default function Expenses(){
  const d = load();
  const [query, setQuery] = useState('');
  const filtered = useMemo(()=> d.transactions.filter(t => t.category.toLowerCase().includes(query.toLowerCase())), [d.transactions, query]);

  return (
    <div className="h-full p-5">
      <div className="flex items-center gap-3 mb-3">
        <Mascot sheet="2x2" index={0} size={40}/>
        <h1 className="text-xl font-bold">Expenses</h1>
      </div>
      <input value={query} onChange={(e)=>setQuery(e.target.value)} placeholder="Search category..." className="w-full border rounded-xl px-3 py-2 mb-3"/>
      <ul className="space-y-2">
        {filtered.map(tx => (
          <li key={tx.id} className="flex justify-between bg-neutral-50 rounded-xl px-3 py-2">
            <span>{tx.emoji || ''} {tx.category}</span>
            <span className={`${tx.type==='expense'?'text-red-600':'text-green-600'}`}>{tx.type==='expense'?'−':"+"} ₹{tx.amount}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
