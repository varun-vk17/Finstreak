import Mascot from '../components/Mascot.jsx';
import { load, save } from '../store/data.js';
import { useState } from 'react';

export default function Profile(){
  const d = load();
  const [name, setName] = useState(d.user?.name || '');
  const [currency, setCurrency] = useState(d.user?.currency || '₹');

  const saveProfile = () => {
    const nd = load();
    nd.user = { ...(nd.user||{}), name, currency, streak: nd.user?.streak || 0 };
    save(nd);
    alert('Profile saved.');
  };

  return (
    <div className="h-full p-5 space-y-4">
      <div className="flex items-center gap-3">
        <Mascot sheet="2x2" index={3} size={40}/>
        <h1 className="text-xl font-bold">Profile</h1>
      </div>
      <div className="space-y-2">
        <label className="text-sm">Name</label>
        <input value={name} onChange={e=>setName(e.target.value)} className="w-full border rounded-xl px-3 py-2"/>
      </div>
      <div className="space-y-2">
        <label className="text-sm">Currency</label>
        <input value={currency} onChange={e=>setCurrency(e.target.value)} className="w-full border rounded-xl px-3 py-2"/>
      </div>
      <button onClick={saveProfile} className="bg-brand text-white px-4 py-2 rounded-xl">Save</button>
    </div>
  );
}
