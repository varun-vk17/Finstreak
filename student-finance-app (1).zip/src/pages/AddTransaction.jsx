import { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { addTx, load, save } from '../store/data.js';

const cats = [
  {label:'🍔 Food', value:'Food', emoji:'🍔'},
  {label:'🚕 Travel', value:'Travel', emoji:'🚕'},
  {label:'🎉 Fun', value:'Fun', emoji:'🎉'},
  {label:'📚 Books', value:'Books', emoji:'📚'},
  {label:'💡 Other', value:'Other', emoji:'💡'}
];

export default function AddTransaction(){
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('Food');
  const [type, setType] = useState('expense');
  const nav = useNavigate();
  const [params] = useSearchParams();

  useEffect(()=>{
    const t = params.get('type');
    if(t === 'income') setType('income');
  }, [params]);

  const submit = (e) => {
    e.preventDefault();
    const sel = cats.find(c=>c.value===category);
    addTx({ type, amount: Number(amount)||0, category, emoji: sel?.emoji || '' , date: new Date().toISOString().slice(0,10) });
    const d = load();
    d.user = { ...(d.user||{}), streak: (d.user?.streak||0)+1 };
    save(d);
    nav('/home');
  };

  return (
    <div className="h-full flex items-center justify-center bg-gray-50">
      <form onSubmit={submit} className="bg-white p-6 rounded-2xl shadow w-80 space-y-4">
        <h1 className="text-xl font-bold">Add Transaction</h1>
        <div className="grid grid-cols-2 gap-2">
          <button type="button" onClick={()=>setType('expense')} className={"rounded-xl py-2 border "+(type==='expense'?'bg-red-50 border-red-300':'')}>Expense</button>
          <button type="button" onClick={()=>setType('income')} className={"rounded-xl py-2 border "+(type==='income'?'bg-green-50 border-green-300':'')}>Income</button>
        </div>
        <input type="number" placeholder="Amount" value={amount} onChange={e=>setAmount(e.target.value)} className="w-full border rounded p-2" required />
        <select value={category} onChange={e=>setCategory(e.target.value)} className="w-full border rounded p-2">
          {cats.map(c=> <option key={c.value} value={c.value}>{c.label}</option>)}
        </select>
        <button type="submit" className="w-full bg-blue-600 text-white py-2 rounded-xl">Save</button>
      </form>
    </div>
  );
}
