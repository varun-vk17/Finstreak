import Mascot from '../components/Mascot.jsx';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { load, save } from '../store/data.js';

export default function Onboarding(){
  const nav = useNavigate();
  const existing = load();
  const [name, setName] = useState(existing.user?.name || '');
  const [balance, setBalance] = useState(existing.balance || '');
  const [currency, setCurrency] = useState(existing.user?.currency || '₹');

  const submit = (e) => {
    e.preventDefault();
    const d = load();
    d.user = { name, currency, streak: d.user?.streak || 1 };
    d.balance = Number(balance)||0;
    d.emergency = d.emergency || 0;
    save(d);
    nav('/home');
  };

  return (
    <div className="h-full flex items-center justify-center bg-blue-100">
      <form onSubmit={submit} className="bg-white p-6 rounded-2xl shadow w-80 space-y-4 text-center">
        <div className="flex justify-center"><Mascot sheet="3x3" index={0} size={64}/></div>
        <h1 className="text-xl font-bold">Welcome</h1>
        <input type="text" placeholder="Your name" value={name} onChange={e=>setName(e.target.value)} className="w-full border rounded p-2" required />
        <input type="number" placeholder="Starting Balance" value={balance} onChange={e=>setBalance(e.target.value)} className="w-full border rounded p-2" required />
        <input type="text" placeholder="Currency (e.g., ₹)" value={currency} onChange={e=>setCurrency(e.target.value)} className="w-full border rounded p-2" />
        <button type="submit" className="w-full bg-blue-600 text-white py-2 rounded-xl">Get Started</button>
      </form>
    </div>
  );
}
