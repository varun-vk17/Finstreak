import Mascot from '../components/Mascot.jsx';
import { load, setEmergency } from '../store/data.js';
import { useState } from 'react';

export default function Savings(){
  const d = load();
  const [lock, setLock] = useState(d.emergency || 0);
  const savedPct = Math.min(100, Math.round((d.emergency / Math.max(1, d.balance + d.emergency))*100));

  const saveLock = () => {
    setEmergency(Number(lock)||0);
    alert('Emergency wallet updated.');
  };

  return (
    <div className="h-full p-5">
      <div className="flex items-center gap-3 mb-3">
        <Mascot sheet="3x3" index={4} size={40}/>
        <h1 className="text-xl font-bold">Savings & Emergency</h1>
      </div>
      <div className="bg-neutral-50 rounded-2xl p-4 mb-4">
        <div className="mb-2">Emergency Wallet (locked):</div>
        <input type="number" value={lock} onChange={e=>setLock(e.target.value)} className="border rounded-xl px-3 py-2 w-full"/>
        <button onClick={saveLock} className="mt-3 bg-brand text-white px-4 py-2 rounded-xl">Save</button>
      </div>
      <div className="bg-green-100 rounded-2xl p-4">
        <div className="font-semibold mb-2">🐖 Piggy Bank</div>
        <div className="w-full bg-white h-3 rounded-full overflow-hidden border border-green-200">
          <div className="h-3 bg-green-500" style={{width: savedPct+'%'}}></div>
        </div>
        <div className="text-xs text-neutral-600 mt-1">{savedPct}% filled</div>
      </div>
    </div>
  );
}
