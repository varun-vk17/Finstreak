import Mascot from '../components/Mascot.jsx';
import { load } from '../store/data.js';

export default function Budget(){
  const d = load();
  const totals = d.transactions.reduce((acc, t)=>{
    if(t.type!=='expense') return acc;
    acc[t.category] = (acc[t.category]||0)+t.amount;
    return acc;
  },{});
  const entries = Object.entries(totals);
  const sum = entries.reduce((a, [_,v])=>a+v, 0);

  return (
    <div className="h-full p-5">
      <div className="flex items-center gap-3 mb-3">
        <Mascot sheet="3x3" index={3} size={40}/>
        <h1 className="text-xl font-bold">Budget</h1>
      </div>
      {entries.length===0 ? <p className="text-neutral-500">No expenses yet.</p> : (
        <div className="space-y-3">
          {entries.map(([cat, val])=>{
            const pct = Math.round((val/sum)*100);
            return (
              <div key={cat}>
                <div className="flex justify-between text-sm mb-1"><span>{cat}</span><span>{pct}%</span></div>
                <div className="w-full bg-neutral-200 h-2 rounded-full overflow-hidden">
                  <div className="h-2 bg-brand" style={{width: pct+'%'}}></div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
