import Mascot from './Mascot.jsx';
import { Flame } from 'lucide-react';
import { load } from '../store/data.js';

export default function Header({poseIndex=0}){
  const d = load();
  const name = d.user?.name || 'Student';
  const streak = d.user?.streak || 0;
  return (
    <div className="flex items-center justify-between px-5 pt-5">
      <div className="flex items-center gap-3">
        <Mascot sheet="3x3" index={poseIndex} size={52}/>
        <div>
          <h1 className="font-bold text-lg">Hi, {name}! 👋</h1>
          <div className="flex items-center gap-1 text-sm text-neutral-500"><Flame className="w-4 h-4 text-orange-500"/> {streak}-day streak</div>
        </div>
      </div>
    </div>
  );
}
