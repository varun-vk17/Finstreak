import { load } from '../store/data.js';
import Mascot from './Mascot.jsx';

export default function Nudges(){
  const d = load();
  const expenses = d.transactions.filter(t=>t.type==='expense');
  const dailyAvg = expenses.length ? Math.round(expenses.reduce((a,t)=>a+t.amount,0)/Math.max(1, new Set(d.transactions.map(t=>t.date)).size)) : 0;
  const daysLeft = dailyAvg>0 ? Math.max(0, Math.floor(d.balance / dailyAvg)) : '∞';

  const cards = [
    { title: 'Today's Tip', text: 'Save ₹50 on coffee ☕', pose: 4 },
    { title: 'Forecast', text: `Runway: ${daysLeft} days`, pose: 8 }
  ];

  return (
    <div className="px-5">
      <div className="text-base font-semibold mb-2">Playful Nudges</div>
      <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-1">
        {cards.map((c,i)=> (
          <div key={i} className="min-w-[320px] rounded-2xl p-4 shadow flex items-center justify-between bg-yellow-100">
            <div className="max-w-[220px]">
              <div className="font-bold">{c.title}</div>
              <div className="text-sm mt-0.5">{c.text}</div>
            </div>
            <Mascot sheet="3x3" index={c.pose} size={48}/>
          </div>
        ))}
      </div>
    </div>
  );
}
