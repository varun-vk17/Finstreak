import { load } from '../store/data.js';

export default function TransactionList(){
  const d = load();
  const txs = d.transactions;
  return (
    <div className="px-5 mt-4 flex-1 overflow-y-auto">
      <h3 className="font-bold mb-2">Recent Transactions</h3>
      {txs.length===0 ? <p className="text-neutral-500">No transactions yet.</p> : (
        <ul className="space-y-2">
          {txs.map(tx => (
            <li key={tx.id} className="flex justify-between items-center bg-neutral-50 rounded-xl px-3 py-2">
              <span className="text-sm">{(tx.emoji || '')} {tx.category}</span>
              <span className={`text-sm ${tx.type==='expense'?'text-red-600':'text-green-600'}`}>
                {tx.type==='expense'?'−':"+"} ₹{tx.amount}
              </span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
