import { load } from '../store/data.js';
import { Link } from 'react-router-dom';
import { Plus } from 'lucide-react';

export default function BalanceCard(){
  const { balance, emergency } = load();
  return (
    <div className="text-center my-3 px-4">
      <div className="flex items-center justify-center gap-2">
        <div className="text-3xl font-extrabold">₹{Number(balance||0).toLocaleString('en-IN')}</div>
        <Link to="/add?type=income" className="bg-brand text-white rounded-full p-2" aria-label="Add balance">
          <Plus className="w-4 h-4"/>
        </Link>
      </div>
      <div className="text-neutral-500">Current Balance</div>
      <div className="text-sm text-neutral-600 mt-1">Emergency Wallet: ₹{Number(emergency||0).toLocaleString('en-IN')} 🔒</div>
    </div>
  );
}
