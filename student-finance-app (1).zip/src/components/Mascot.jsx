export default function Mascot({sheet='3x3', index=0, size=56}){
  const img = sheet==='3x3' ? '/mascot/mascot-sprite-3x3.png' : '/mascot/mascot-sprite-2x2.png';
  const cols = sheet==='3x3' ? 3 : 2;
  const rows = sheet==='3x3' ? 3 : 2;
  const col = index % cols;
  const row = Math.floor(index / cols);
  const bgSize = `${cols*100}% ${rows*100}%`;
  const bgPos = `${(col/(cols-1))*100}% ${(row/(rows-1))*100}%`;
  return (
    <div
      className="rounded-2xl"
      style={{
        width: size, height: size,
        backgroundImage: `url(${img})`,
        backgroundSize: bgSize,
        backgroundPosition: bgPos,
        backgroundRepeat: 'no-repeat'
      }}
      aria-hidden="true"
    />
  );
}
