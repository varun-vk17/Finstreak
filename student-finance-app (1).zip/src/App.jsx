import { Routes, Route, NavLink, useLocation } from "react-router-dom";
import Home from "./pages/Home.jsx";
import Expenses from "./pages/Expenses.jsx";
import Budget from "./pages/Budget.jsx";
import Forecast from "./pages/Forecast.jsx";
import Savings from "./pages/Savings.jsx";
import Profile from "./pages/Profile.jsx";
import Onboarding from "./pages/Onboarding.jsx";
import AddTransaction from "./pages/AddTransaction.jsx";
import { HomeIcon, Wallet, BarChart2, PiggyBank, User } from "lucide-react";

export default function App(){
  return <Frame/>;
}

function Frame(){
  const loc = useLocation();
  return (
    <div className="mx-auto max-w-sm h-screen bg-white rounded-[2rem] shadow-xl overflow-hidden border border-neutral-100">
      <Routes>
        <Route path="/" element={<Onboarding/>} />
        <Route path="/home" element={<Home/>} />
        <Route path="/expenses" element={<Expenses/>} />
        <Route path="/budget" element={<Budget/>} />
        <Route path="/forecast" element={<Forecast/>} />
        <Route path="/savings" element={<Savings/>} />
        <Route path="/profile" element={<Profile/>} />
        <Route path="/add" element={<AddTransaction/>} />
      </Routes>
      { !['/','/add'].includes(loc.pathname) && <Tabs/> }
    </div>
  );
}

function Tabs(){
  return (
    <nav className="grid grid-cols-5 border-t bg-white/95 backdrop-blur py-2">
      <Tab to="/home" label="Home" icon={<HomeIcon className="w-6 h-6"/>}/>
      <Tab to="/expenses" label="Expenses" icon={<Wallet className="w-6 h-6"/>}/>
      <Tab to="/budget" label="Budget" icon={<BarChart2 className="w-6 h-6"/>}/>
      <Tab to="/savings" label="Savings" icon={<PiggyBank className="w-6 h-6"/>}/>
      <Tab to="/profile" label="Profile" icon={<User className="w-6 h-6"/>}/>
    </nav>
  );
}

function Tab({to,label,icon}){
  return (
    <NavLink to={to} end className={({isActive})=>`flex flex-col items-center py-1 text-xs ${isActive? 'text-brand font-semibold':'text-neutral-500'}`}>
      {icon}
      <span className="mt-0.5">{label}</span>
    </NavLink>
  );
}
