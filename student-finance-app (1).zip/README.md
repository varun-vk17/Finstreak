# Student Finance App
Polished, mascot-powered student finance app.

## Run
```bash
npm install
npm run dev
```

Starts empty. Everything you see is what you input. Data persists in LocalStorage.
